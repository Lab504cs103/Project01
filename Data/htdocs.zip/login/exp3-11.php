<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>無標題文件</title>
<style type="text/css">
body {
	background-image: url(wcygb.gif);
}
</style>
</head>

<body>
<div align="center"><img src="教材/CH11.PNG" width="953" height="562"  alt=""/></div>
</body>
</html>