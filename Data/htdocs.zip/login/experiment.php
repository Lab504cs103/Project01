<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>無標題文件</title>
<style type="text/css">
body {
	background-image: url(../bg_sora2.gif);
	text-align: center;
}
</style>
<script type="text/javascript">
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
</script>
</head>

<body>
<img src="ctes4t75s7d0.JPG" width="695" height="397" usemap="#Map" border="0" />
<map name="Map" id="Map">
  <area shape="circle" coords="71,85,54" onclick="MM_openBrWindow('../index_test.html','R1','toolbar=yes,menubar=yes,scrollbars=yes,resizable=yes,width=600,height=600')" />
  <area shape="circle" coords="340,81,54" onclick="MM_openBrWindow('../index_test.html','R3','scrollbars=yes,width=600,height=600')" />
  <area shape="circle" coords="617,86,56" onclick="MM_openBrWindow('../index_test.html','','scrollbars=yes,resizable=yes,width=600,height=600')" />
  <area shape="circle" coords="73,323,60" href="#" />
  <area shape="circle" coords="616,336,60" href="#" />
</map>
</body>
</html>