<!-- 設定網頁編碼為UTF-8 -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
body {
	background-image: url(bg_sora2.gif);
}
</style>
<form name="form" method="post" action="connect.php">
  <center>
  <p><img src="blue_plain_welcome.gif" width="360" height="120" alt="welcome" /></p>
  <p>帳號：<input name="id" type="text" id="id" /> <br>密碼：<input name="pw" type="password" id="pw" /> <br>
    <input name="button" type="submit" value="登入" /> &nbsp;&nbsp;
  <a href="register.php">申請帳號</a></p></center>
</form>
