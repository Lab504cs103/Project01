<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>無標題文件</title>
<style type="text/css">
body {
	background-image: url(slcy.gif);
}
.blue {
	color: #09F;
	font-family: "標楷體";
}
.blue a {
	font-family: "標楷體";
}
</style>
</head>

<body>
<table width="1084" border="1" align="center">
  <tr>
    <th width="210" height="27" class="blue" scope="col"><a href="member.php" target=f2>使用者資訊</a></th>
    <th width="210" class="blue" scope="col"><a href="GClab/index.html" target=f2>預約</a></th>
    <th width="210" class="blue" scope="col"><a href="list.php" target=f2>實驗</a></th>
    <th width="210" class="blue" scope="col">留言板</th>
    <th width="210" class="blue" scope="col"><a href="logout.php">登出</a></th>
  </tr>
</table>
</body>
</html>