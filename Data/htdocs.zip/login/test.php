<html>
<body>
<?php
	echo $_GET['com'];
?>
</body>