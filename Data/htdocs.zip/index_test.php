<?php
	session_start();
	$_SESSION['com'] = $_GET["com"];
?>
<frameset rows=*,10%>
　　<frame src="test2.php" name=f2>
　　<frame src="input_test.htm" name=f1>
</frameset><noframes></noframes>
