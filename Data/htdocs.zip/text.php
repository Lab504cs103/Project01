<?php
echo $_POST[msg];
?>