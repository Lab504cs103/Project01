﻿<script type="text/javascript" language="javascript">  
    //DIV的滚动条始终显示聊天窗口最底部   
      function  setDIV()  {  
            var div = document.getElementByIdx_x_x('msg');  
            div.scrollTop = div.scrollHeight;   
            //切忌setTimeout一定要放在这里，勿放onload里面，否则div的滚动条只能指在倒数第2行         
             setTimeout('setDIV()', 200);  //如果去掉定时刷新，屏蔽此行
      }  
       window.onload = function() {setDIV();}  
</script>  
<div id="msg" style="width: 420px; height: 150px; overflow-y: scroll; border: 1px solid #999; overflow: auto; background-color: #FFFFFF">  
</div>  


<input type="button" value="发送" onclick="setDIV();">  