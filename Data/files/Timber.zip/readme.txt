Installation:
(This is written on the premise you know how to get to your minecraft.jar)

0. Put on your robe and wizard hat.
1. Backup your minecraft.jar.
2. Delete META-INF.
3. Install ForgeModLoader or ModLoader.
4. Copy this .zip into /.minecraft/mods/
5. Start up minecraft and play.

MagicLauncher may complain about Timber. I don't know why it does this, but Timber does not absolutely require Forge like MagicLauncher claims it does. Timber uses either Forge or ModLoader.